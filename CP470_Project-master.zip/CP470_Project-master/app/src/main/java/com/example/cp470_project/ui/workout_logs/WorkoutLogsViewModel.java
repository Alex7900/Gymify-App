package com.example.cp470_project.ui.workout_logs;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class WorkoutLogsViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public WorkoutLogsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is home fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}