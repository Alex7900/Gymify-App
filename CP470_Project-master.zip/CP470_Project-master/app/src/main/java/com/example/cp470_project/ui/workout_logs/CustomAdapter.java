package com.example.cp470_project.ui.workout_logs;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_project.R;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomViewHolder> {

    Context context;
    ArrayList<WorkoutLog> workoutLogs;


    public CustomAdapter(Context ctx, ArrayList<WorkoutLog> workoutLogs) {
        this.context = ctx;
        this.workoutLogs = workoutLogs;
    }
    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {
        return new CustomViewHolder(LayoutInflater.from(context).inflate(R.layout.workout_log_item_views,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        holder.titleTV.setText(workoutLogs.get(position).getTitle());
        holder.timeDurationTV.setText(workoutLogs.get(position).getTimeDuration());
        holder.dayTV.setText(workoutLogs.get(position).getDayName());
        holder.monthTV.setText(workoutLogs.get(position).getMonth());
        holder.dateNumTV.setText(workoutLogs.get(position).getDayNum());
    }

    @Override
    public int getItemCount() {
        return workoutLogs.size();
    }
}
