package com.example.cp470_project.ui.workout_logs;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_project.R;

public class CustomViewHolder extends RecyclerView.ViewHolder {

    TextView titleTV, timeDurationTV, dayTV, dateNumTV, monthTV;

    public CustomViewHolder(@NonNull View itemView) {
        super(itemView);
        titleTV = itemView.findViewById(R.id.workout_log_title);
        timeDurationTV = itemView.findViewById(R.id.workout_log_time_duration);
        dayTV = itemView.findViewById(R.id.workout_log_day_created);
        dateNumTV = itemView.findViewById(R.id.workout_log_date_no_created);
        monthTV = itemView.findViewById(R.id.workout_log_date_month_created);
    }
}
