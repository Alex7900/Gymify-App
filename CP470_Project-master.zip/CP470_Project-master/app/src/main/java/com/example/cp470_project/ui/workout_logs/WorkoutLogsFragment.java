package com.example.cp470_project.ui.workout_logs;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.cp470_project.databinding.FragmentWorkoutLogsBinding;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class WorkoutLogsFragment extends Fragment {

    private FragmentWorkoutLogsBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentWorkoutLogsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        ArrayList<WorkoutLog> workoutLogs = new ArrayList<WorkoutLog>();

        for (int i = 1; i < 14; i++) {
            LocalDate dateCreated = LocalDate.now().plusDays(i);
            LocalTime timeStarted = LocalTime.now();
            LocalTime timeEnded = LocalTime.now().plusMinutes(60+i);

            if (dateCreated.getDayOfWeek() == DayOfWeek.MONDAY || dateCreated.getDayOfWeek() == DayOfWeek.THURSDAY) {
                workoutLogs.add(new WorkoutLog("Push (Chest, Shoulders, Triceps)", dateCreated, timeStarted, timeEnded));
            } else if (dateCreated.getDayOfWeek() == DayOfWeek.TUESDAY || dateCreated.getDayOfWeek() == DayOfWeek.FRIDAY) {
                workoutLogs.add(new WorkoutLog("Pull (Back, Biceps)", dateCreated, timeStarted, timeEnded));
            } else if (dateCreated.getDayOfWeek() == DayOfWeek.WEDNESDAY || dateCreated.getDayOfWeek() == DayOfWeek.SATURDAY) {
                workoutLogs.add(new WorkoutLog("Legs (Quads, Hamstrings, Calves)", dateCreated, timeStarted, timeEnded));
            }
        }

        binding.workoutLogsRecylcerview.setLayoutManager(new LinearLayoutManager(container.getContext()));
        binding.workoutLogsRecylcerview.setAdapter(new CustomAdapter(container.getContext(), workoutLogs));


        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}