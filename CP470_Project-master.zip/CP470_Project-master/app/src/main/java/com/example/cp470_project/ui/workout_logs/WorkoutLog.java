package com.example.cp470_project.ui.workout_logs;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;

public class WorkoutLog {
    String title;
    String timeDuration;
    int day_num;
    Month month;
    DayOfWeek day_name;
    int year;
    LocalTime timeStarted;
    LocalTime timeEnded;

    public WorkoutLog(String title, LocalDate dateCreated, LocalTime timeStarted, LocalTime timeEnded) {

        this.title = title;
        this.timeDuration = String.format("%d mins", Duration.between(timeStarted, timeEnded).toMinutes());
        this.day_name = dateCreated.getDayOfWeek();
        this.day_num = dateCreated.getDayOfMonth();
        this.month = dateCreated.getMonth();
        this.year = dateCreated.getYear();
        this.timeStarted = timeStarted;
        this.timeEnded = timeEnded;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTimeDuration() {
        return timeDuration;
    }

    public void setTimeDuration(LocalTime timeStarted, LocalTime timeEnded) {
        this.timeDuration = String.format("%d mins", Duration.between(timeStarted, timeEnded).toMinutes());
    }

    public String getDayName() {
        return day_name.toString();
    }

    public void setDayName(LocalDate dateCreated) {
        this.day_name = dateCreated.getDayOfWeek();
    }

    public String getDayNum() {
        return Integer.toString(day_num);
    }

    public void setDayNum(LocalDate dateCreated) {
        this.day_num = dateCreated.getDayOfMonth();
    }

    public String getMonth() {
        return month.toString();
    }

    public void setMonth(LocalDate dateCreated) {
        this.month = dateCreated.getMonth();
    }

    public int getYear() {
        return year;
    }

    public void setYear(LocalDate dateCreated) {
        this.year = dateCreated.getYear();
    }

    public LocalTime getTimeStarted() {
        return timeStarted;
    }

    public void setTimeStarted(LocalTime timeStarted) {
        this.timeStarted = timeStarted;
    }

    public LocalTime getTimeEnded() {
        return timeEnded;
    }

    public void setTimeEnded(LocalTime timeEnded) {
        this.timeEnded = timeEnded;
    }
}
