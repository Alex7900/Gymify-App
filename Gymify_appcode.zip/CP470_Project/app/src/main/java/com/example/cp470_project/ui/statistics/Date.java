package com.example.cp470_project.ui.statistics;

public class Date {
    private int day;
    private String notes;
    private Boolean is_chest;
    private Boolean is_leg;
    private Boolean is_pull;
    public Date (int day,String status, String notes){
        this.day = day;
        this.notes = notes;
        this.is_chest = false;
        this.is_pull = false;
        this.is_leg = false;
    }

    public Date (){
        this.day = 0;
        this.notes = "";
        this.is_chest = false;
        this.is_pull = false;
        this.is_leg = false;
    }

    public int getDay(){
        return this.day;
    }

    public boolean setDay(int day){
        this.day = day;
        return true;
    }

    public String getNotes(){
        return this.notes;
    }

    public boolean setNotes(String notes){
        this.notes = notes;
        return true;
    }

    public String toString(){
        if (this.day == 0){
            return "";
        }
        return String.valueOf(this.day);
    }
    public void setIsChest(Boolean is_chest){
        this.is_chest = is_chest;
    }

    public Boolean isChest(){
        return this.is_chest;
    }

    public void setIsLeg(Boolean is_leg){
        this.is_leg = is_leg;
    }

    public Boolean isLeg(){
        return this.is_leg;
    }

    public void setIsPull(Boolean is_pull){
        this.is_pull = is_pull;
    }

    public Boolean isPull(){
        return this.is_pull;
    }

}
