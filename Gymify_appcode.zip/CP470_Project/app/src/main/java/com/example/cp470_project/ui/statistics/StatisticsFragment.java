package com.example.cp470_project.ui.statistics;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_project.R;
import com.example.cp470_project.databinding.FragmentCalendarBinding;
import com.example.cp470_project.ui.data.DatabaseHelper;
import com.example.cp470_project.ui.workout_logs.WorkoutLog;
import com.google.android.material.snackbar.Snackbar;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class StatisticsFragment extends Fragment implements CalendarAdapter.OnItemListener{
    private static final String TAG = "Statistics";
    private LocalDate selectedDate;
    private FragmentCalendarBinding binding;
    private Context ctx;
    private DatabaseHelper helper;
    private SQLiteDatabase db;
    private Cursor cursor;
    private int chest_count;
    private int leg_count;
    private int pull_count;
    private int total_count;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        StatisticsViewModel statisticsViewModel =
                new ViewModelProvider(this).get(StatisticsViewModel.class);

        binding = FragmentCalendarBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        this.ctx = container.getContext();

        // Init database
        helper = new DatabaseHelper(container.getContext());
        db = helper.getWritableDatabase();

        bindButtons();
        createCalendar();

        return root;
    }

    private void bindButtons() {
        binding.btnPrevMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getPrevMonth();
            }
        });

        binding.btnNextMonth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getNextMonth();
            }
        });

        binding.fabAboutStats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayInfo();
            }
        });
    }

    private void createCalendar(){
        selectedDate = LocalDate.now();

        update();
    }

    private void displayInfo(){
        AlertDialog.Builder builder = new AlertDialog.Builder(ctx);
        builder.setTitle(getString(R.string.stats_info_title));
        final View customLayout = getLayoutInflater().inflate(R.layout.info_dialog,null);
        TextView text = customLayout.findViewById(R.id.info_text);
        text.setText(getString(R.string.stats_info_desc));
        builder.setView(customLayout);
        builder.setPositiveButton(getString(R.string.ok), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Snackbar.make(binding.getRoot(),getString(R.string.info_exit),Snackbar.LENGTH_SHORT)
                        .setAnchorView(binding.fabAboutStats)
                        .show();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();


    }

    private void update() {
        update_calendar();
        update_statistics();
    }

    private void update_statistics(){
        ArrayList<Stat> stats_array = new ArrayList<>();

        int chest_percent = 0;
        int leg_percent = 0;
        int pull_percent = 0;

        // Check if greater than 0 to avoid div by 0
        if (total_count > 0){
            chest_percent = (int) chest_count*100/total_count;
            leg_percent = (int) leg_count*100/total_count;
            pull_percent = (int) pull_count*100/total_count;
        }

        // Stat bars
        stats_array.add(new Stat(formatStatText(getString(R.string.chestStatName),10),chest_percent));
        stats_array.add(new Stat(formatStatText(getString(R.string.legStatName),10),leg_percent));
        stats_array.add(new Stat(formatStatText(getString(R.string.pullStatName),10),pull_percent));

        // Clear views that contains previous statistics
        binding.statisticsRecycler.removeAllViews();

        Log.d(TAG,String.valueOf(chest_count));

        binding.statisticsRecycler.setLayoutManager(new LinearLayoutManager(ctx,LinearLayoutManager.VERTICAL,false));
        StatisticsAdapter statisticsAdapter = new StatisticsAdapter(ctx,stats_array);
        binding.statisticsRecycler.setAdapter(statisticsAdapter);
    }

    private String formatStatText(String s, int length){
        return String.format("%-"+length+"s",s);
    }

    private void update_calendar(){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM yyyy");
        String formattedString = selectedDate.format(formatter);
        binding.monthYearView.setText(formattedString);

        ArrayList<Date> daysInMonth = new ArrayList<>();
        YearMonth yearMonth = YearMonth.from(selectedDate);
        int numDaysMonth = yearMonth.lengthOfMonth();

        int dayOfWeek = selectedDate.withDayOfMonth(1).getDayOfWeek().getValue();

        for (int i=1;i<42;i++){
            Date date = new Date();
            if (i > dayOfWeek && i <= numDaysMonth + dayOfWeek) {
                // Is a proper day of the month
                date.setDay(i - dayOfWeek);
            } else{
                // Not a proper day
                date.setDay(0);
            }
            daysInMonth.add(date);
        }

        daysInMonth = update_schedule(daysInMonth, dayOfWeek);

        Log.d("stats",String.valueOf(daysInMonth));
        CalendarAdapter calendarAdapter = new CalendarAdapter(daysInMonth,this);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(ctx,7);
        binding.calendarRecycler.setLayoutManager(layoutManager);
        binding.calendarRecycler.setAdapter(calendarAdapter);
    }
    private ArrayList<Date> update_schedule(ArrayList<Date> daysInMonth, int dayOfWeek){
        String month = String.valueOf(selectedDate.getMonthValue());
        String year = String.valueOf(selectedDate.getYear());
        final String query = "SELECT " + helper.KEY_WORKOUT_LOG_TITLE +
                ", " + helper.KEY_WORKOUT_LOG_DATE_CREATED +
                " FROM " + helper.TABLE_NAME_WORKOUT_LOG +
                " WHERE " + helper.KEY_WORKOUT_LOG_DATE_CREATED + " LIKE '" +
                year + "-" + month + "-__';";
        Log.i(TAG,query);

        chest_count = 0;
        leg_count = 0;
        pull_count = 0;
        total_count = 0;

        cursor = db.rawQuery(query,null);
        if (cursor.moveToFirst()){
            do{
                int title_index = cursor.getColumnIndex( helper.KEY_WORKOUT_LOG_TITLE);
                int date_index = cursor.getColumnIndex( helper.KEY_WORKOUT_LOG_DATE_CREATED);
                String date = cursor.getString(date_index);
                String title = cursor.getString(title_index);
                //Log.i(TAG,"Title: " + cursor.getString(title_index));
                //Log.i(TAG,"Date: " + cursor.getString(date_index));

                int length = date.length();
                String sDay = String.valueOf(date.charAt(length-2)) + date.charAt(length-1);
                int day = Integer.valueOf(sDay);
                //Log.i(TAG,title);
                int i = day + dayOfWeek - 1;
                if (title.equals("Chest")){
                    daysInMonth.get(i).setIsChest(true);
                    String notes = daysInMonth.get(i).getNotes();
                    if (!notes.contains("Chest")){
                        daysInMonth.get(i).setNotes(notes + "Chest ");
                    }
                    chest_count += 1;
                } else if (title.equals("Leg")){
                    daysInMonth.get(i).setIsLeg(true);
                    String notes = daysInMonth.get(i).getNotes();
                    if (!notes.contains("Leg")){
                        daysInMonth.get(i).setNotes(notes + "Leg ");
                    }
                    leg_count += 1;
                } else if (title.equals("Pull")){
                    daysInMonth.get(i).setIsPull(true);
                    daysInMonth.get(i).setNotes(daysInMonth.get(i).getNotes() + "Pull ");
                    String notes = daysInMonth.get(i).getNotes();
                    if (!notes.contains("Pull")){
                        daysInMonth.get(i).setNotes(notes + "Pull ");
                    }
                    pull_count += 1;
                }
                total_count = chest_count + leg_count + pull_count;

                //Log.i(TAG,sDay);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return daysInMonth;
    }

    public void getPrevMonth() {
        selectedDate = selectedDate.minusMonths(1);
        update();
    }
    public void getNextMonth() {
        selectedDate = selectedDate.plusMonths(1);
        update();
    }

    @Override
    public void onItemClick(int position, String dayText) {
        if (!dayText.equals("")){
            Toast toast = Toast.makeText(ctx, dayText, Toast.LENGTH_SHORT);
            toast.show();
        }
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}