package com.example.cp470_project.ui.workout;

import com.example.cp470_project.ui.workout_set.WorkoutSet;
import java.util.List;

public class Workout {
    private List<WorkoutSet> workout;
    public Workout(List<WorkoutSet> workout) {
        this.workout = workout;
    }
    public List<WorkoutSet> getWorkout() {
        return workout;
    }
    public void setWorkout(List<WorkoutSet> workout) {
        this.workout = workout;
    }
}