package com.example.cp470_project.ui.workout_logs;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.cp470_project.R;
import com.example.cp470_project.Routine;
import com.example.cp470_project.databinding.FragmentWorkoutLogsBinding;
import com.example.cp470_project.ui.data.DatabaseHelper;
import com.example.cp470_project.ui.workout.WorkoutActivity;
import com.example.cp470_project.ui.workout_set.WorkoutSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class WorkoutLogsFragment extends Fragment {

    private FragmentWorkoutLogsBinding binding;
    public final static String ARG_OBJECT_NAME = "WorkoutLog";
    public final static String ARG_POSITION = "position";
    public final static String ARG_EXERCISES = "exercises";
    public final static String ARG_IS_NEW_SESSION = "isNewSession";
    public final static int CODE_REQUEST = 500;
    public final static int CODE_RESULT = 100;
    public final static String FRAGMENT_NAME = "WorkoutLogsFragment";
    private List<WorkoutLog> workoutLogs;
    private Map<String, Routine> routines;
    private String[] workoutRoutineName;
    private boolean isNewSession = false;
    private SQLiteDatabase db;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentWorkoutLogsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        DatabaseHelper databaseHelper = new DatabaseHelper(container.getContext());
        db = databaseHelper.getWritableDatabase();

        workoutLogs = getSavedWorkoutLogs();

        try {
            routines = getRoutines();
            workoutRoutineName = routines.keySet().toArray(new String[routines.size()]);
            Log.i(FRAGMENT_NAME, "keys: " + Arrays.toString(workoutRoutineName));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(container.getContext());
        binding.workoutLogsRecyclerview.setLayoutManager(linearLayoutManager);
        WorkoutLogsAdapter workoutLogsAdapter = new WorkoutLogsAdapter(workoutLogs);
        binding.workoutLogsRecyclerview.setAdapter(workoutLogsAdapter);
        workoutLogsAdapter.setOnClickListener((position, workoutLog) -> {
            String[] exerciseNames = routines.get(workoutLog.getRoutineTitle()).getExercises().toArray(new String[routines.get(workoutLog.getRoutineTitle()).getExercises().size()]);
            Intent intent = new Intent(getActivity(), WorkoutActivity.class);
            intent.putExtra(ARG_OBJECT_NAME, workoutLog);
            intent.putExtra(ARG_POSITION, position);
            intent.putExtra(ARG_EXERCISES, exerciseNames);
            intent.putExtra(ARG_IS_NEW_SESSION, isNewSession);
            startActivityForResult(intent, CODE_REQUEST);
//            isNewSession = false;
        });

        binding.fabAddWorkoutSession.setOnClickListener(view -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            View v = inflater.inflate(R.layout.dialog_new_workout_session, null);
            builder.setView(v);
            builder.setTitle(R.string.alertdialog_new_workout_session_title);

            Spinner spinnerWorkoutRoutine = v.findViewById(R.id.spinner_workout_routine);
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(container.getContext(), android.R.layout.simple_spinner_item, workoutRoutineName);
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinnerWorkoutRoutine.setAdapter(arrayAdapter);

            builder.setPositiveButton(R.string.ok, (dialog, id) -> {
                String title = spinnerWorkoutRoutine.getSelectedItem().toString();
                LocalDate currDate = LocalDate.now();
                LocalTime timeStarted = LocalTime.parse(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")));
                LocalTime timeEnded = LocalTime.parse("00:00", DateTimeFormatter.ofPattern("HH:mm"));
                WorkoutLog workoutLog = new WorkoutLog(title, currDate, timeStarted, timeEnded, title);
                workoutLogs.add(workoutLog);
                isNewSession = true;
//                Log.i(FRAGMENT_NAME, "chosen: " + spinnerWorkoutRoutine.getSelectedItem().toString());
                ContentValues contentValues = new ContentValues();
                contentValues.put(DatabaseHelper.KEY_WORKOUT_LOG_TITLE, title);
                contentValues.put(DatabaseHelper.KEY_WORKOUT_LOG_DATE_CREATED, currDate.toString());
                contentValues.put(DatabaseHelper.KEY_WORKOUT_LOG_TIME_STARTED, timeStarted.toString());
                contentValues.put(DatabaseHelper.KEY_WORKOUT_LOG_TIME_ENDED, timeEnded.toString());
                contentValues.put(DatabaseHelper.KEY_WORKOUT_LOG_ROUTINE_NAME, title);
                long workoutLogID = db.insert(DatabaseHelper.TABLE_NAME_WORKOUT_LOG, "NullPlaceHolder", contentValues);
                workoutLog.setWorkoutID((int) workoutLogID);
                insertNewRowWorkoutData(routines.get(workoutLog.getRoutineTitle()).getExercises().toArray(new String[routines.get(workoutLog.getRoutineTitle()).getExercises().size()]), (int) workoutLogID);

                workoutLogs.sort(new WorkoutLogComparator() {
                    @Override
                    public int compare(WorkoutLog a, WorkoutLog b) {
                        return super.compare(a, b);
                    }
                });
                workoutLogsAdapter.notifyDataSetChanged();
            });
            builder.setNegativeButton(R.string.cancel, (dialog, id) -> {
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        });
        return root;
    }
    private Map<String, Routine> getRoutines() throws JSONException {
        Map<String, Routine> routines = new HashMap<>();
        String sqlQuery = "SELECT * FROM " + DatabaseHelper.TABLE_NAME_WORKOUT_ROUTINES;
        Cursor cursor = db.rawQuery(sqlQuery, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            int cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_ROUTINES_ID);
            int routinesID = cursor.getInt(cursorIndex);
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_ROUTINES_NAME);
            String name = cursor.getString(cursorIndex);
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_ROUTINES_DESCRIPTION);
            String description = cursor.getString(cursorIndex);
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_ROUTINES_EXERCISES);
            JSONArray jsonArray = new JSONArray(cursor.getString(cursorIndex));
            List<String> exerciseNames = new ArrayList<>();
            for (int i = 0; i < jsonArray.length(); i++) {
                exerciseNames.add(jsonArray.getString(i));
            }
            Routine routine = new Routine(name, description, exerciseNames);
            routine.setId(routinesID);
            routines.put(name, routine);
            cursor.moveToNext();
        }
        cursor.close();
        return routines;
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        db.close();
    }
    private List<WorkoutLog> getSavedWorkoutLogs() {
        String sqlQuery = "SELECT * FROM " + DatabaseHelper.TABLE_NAME_WORKOUT_LOG;
        Cursor cursor = db.rawQuery(sqlQuery, null);

        List<WorkoutLog> savedWorkoutLogs = new ArrayList<>();

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            int cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_LOG_ID);
            int workoutLogID = cursor.getInt(cursorIndex);
            Log.i(FRAGMENT_NAME, "SQL MESSAGE:" + cursor.getString(cursorIndex));
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_LOG_TITLE);
            String title = cursor.getString(cursorIndex);
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_LOG_DATE_CREATED);
            LocalDate date = LocalDate.parse(cursor.getString(cursorIndex));
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_LOG_TIME_STARTED);
            LocalTime timeStarted = LocalTime.parse(cursor.getString(cursorIndex));
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_LOG_TIME_ENDED);
            LocalTime timeEnded = LocalTime.parse(cursor.getString(cursorIndex));
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_LOG_ROUTINE_NAME);
            String routineTitle = cursor.getString(cursorIndex);
            WorkoutLog workoutLog = new WorkoutLog(title, date, timeStarted, timeEnded, routineTitle);
            workoutLog.setWorkoutID(workoutLogID);
            savedWorkoutLogs.add(workoutLog);
            cursor.moveToNext();
        }
        cursor.close();
        savedWorkoutLogs.sort(new WorkoutLogComparator() {
            @Override
            public int compare(WorkoutLog a, WorkoutLog b) {
                return super.compare(a, b);
            }
        });
        return savedWorkoutLogs;
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == CODE_REQUEST) {
            if (resultCode == CODE_RESULT) {
                WorkoutLog workoutLog = (WorkoutLog) data.getSerializableExtra(ARG_OBJECT_NAME);
                int position = data.getIntExtra(ARG_POSITION, -1);

                workoutLogs.set(position, workoutLog);
                ContentValues contentValues = new ContentValues();
                contentValues.put(DatabaseHelper.KEY_WORKOUT_LOG_TITLE, workoutLog.getTitle());
                contentValues.put(DatabaseHelper.KEY_WORKOUT_LOG_DATE_CREATED, workoutLog.getDateCreated().toString());
                contentValues.put(DatabaseHelper.KEY_WORKOUT_LOG_TIME_STARTED, workoutLog.getTimeStarted().toString());
                contentValues.put(DatabaseHelper.KEY_WORKOUT_LOG_TIME_ENDED, workoutLog.getTimeEnded().toString());
                db.update(DatabaseHelper.TABLE_NAME_WORKOUT_LOG, contentValues, DatabaseHelper.KEY_WORKOUT_LOG_ID + "=?",new String[]{String.valueOf(workoutLog.getWorkoutID())});
                workoutLogs.sort(new WorkoutLogComparator() {
                    @Override
                    public int compare(WorkoutLog a, WorkoutLog b) {
                        return super.compare(a, b);
                    }
                });
                binding.workoutLogsRecyclerview.getAdapter().notifyDataSetChanged();
            }
        }
    }
    private static class WorkoutLogComparator implements java.util.Comparator<WorkoutLog> {
        @Override
        public int compare(WorkoutLog a, WorkoutLog b) {
            return -a.getDateCreated().compareTo(b.getDateCreated());
        }
    }
    private void insertNewRowWorkoutData(String[] exerciseNames, int workoutLogID) {
        List<List<WorkoutSet>> workoutHistory = new ArrayList<>();
        for (int i = 0; i < exerciseNames.length; i++) {
            workoutHistory.add(new ArrayList<>());
        }

        JSONObject workoutSession = new JSONObject();
        for (int i = 0; i < workoutHistory.size(); i++) {
            JSONArray exercise = new JSONArray();
            for (int j = 0; j < workoutHistory.get(i).size(); j++) {
                JSONArray workoutSet = new JSONArray();
                try {
                    workoutSet.put(workoutHistory.get(i).get(j).getWeight());
                    workoutSet.put(workoutHistory.get(i).get(j).getReps());
                    exercise.put(workoutSet);
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
            try {
                workoutSession.put(exerciseNames[i], exercise);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.KEY_WORKOUT_DATA_DATA, workoutSession.toString());
        contentValues.put(DatabaseHelper.KEY_WORKOUT_DATA_WORKOUT_LOG_ID, workoutLogID);
        db.insert(DatabaseHelper.TABLE_NAME_WORKOUT_DATA, "NullPlaceHolder", contentValues);
    }
}