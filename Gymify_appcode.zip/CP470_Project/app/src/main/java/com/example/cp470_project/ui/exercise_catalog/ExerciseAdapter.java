package com.example.cp470_project.ui.exercise_catalog;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.cp470_project.R;
import com.example.cp470_project.ui.exercise.Exercise;

import java.util.ArrayList;
import java.util.List;

public class ExerciseAdapter extends RecyclerView.Adapter<ExerciseViewHolder> implements Filterable {
    private ArrayList<Exercise> exercises;
    private ArrayList<Exercise> exercisesFull; // Full list to keep track of all items

    private Context context;
    public ExerciseAdapter(Context ctx, ArrayList<Exercise> exercises) {
        this.context = ctx;
        this.exercises= exercises;
        exercisesFull=new ArrayList<>(exercises);
    }

    @NonNull
    @Override
    public ExerciseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ExerciseViewHolder(LayoutInflater.from(context).inflate(R.layout.exercise_catalog_items,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ExerciseViewHolder holder, int position) {
        Exercise exercise = exercises.get(position);
        holder.exerciseName.setText(exercise.getName());
        holder.exerciseDescription.setText(exercise.getDescription());

        int imageResId = context.getResources().getIdentifier(exercise.getImageUrl(), "drawable", context.getPackageName());
        Glide.with(context).load(imageResId).into(holder.exerciseImage);
    }

    @Override
    public int getItemCount() {
        return exercises.size();
    }
    @Override
    public Filter getFilter(){
        return exerciseFilter;
    }

    private Filter exerciseFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            ArrayList<Exercise> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(exercisesFull);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();

                for (Exercise item : exercisesFull) {
                    if (item.getName().toLowerCase().contains(filterPattern)) {
                        filteredList.add(item);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = filteredList;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            exercises.clear();
            exercises.addAll((List) results.values);
            notifyDataSetChanged();
        }
    };
}
