package com.example.cp470_project;

import android.content.ContentValues;

import com.example.cp470_project.ui.data.DatabaseHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class Routine {
    private int id;
    private String name;
    private String description;
    private List<String> exercises;
    public Routine(String name, String description, List<String> exercises) {
        this.name = name;
        this.description = description;
        this.exercises = exercises;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public List<String> getExercises() {
        return exercises;
    }
    public void setExercises(List<String> exercises) {
        this.exercises = exercises;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

}
