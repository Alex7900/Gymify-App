package com.example.cp470_project.ui.workout;

import androidx.lifecycle.ViewModel;

public class WorkoutViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}