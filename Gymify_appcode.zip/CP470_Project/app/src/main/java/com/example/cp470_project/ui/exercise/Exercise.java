package com.example.cp470_project.ui.exercise;
public class Exercise {
    private String name;            // Name of the exercise
    private String description;     // Description of the exercise
    private String imageUrl;        // URL or path to the image representing the exercise


    public Exercise(String name, String description, String imageUrl) {
        this.name = name;
        this.description = description;
        this.imageUrl = imageUrl;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }


}


