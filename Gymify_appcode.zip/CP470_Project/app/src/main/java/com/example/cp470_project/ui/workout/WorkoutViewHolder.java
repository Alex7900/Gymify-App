package com.example.cp470_project.ui.workout;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_project.R;

public class WorkoutViewHolder extends RecyclerView.ViewHolder {
    Button addSetBtn;
    TextView exerciseTitleTv;
    RecyclerView exerciseSetRecyclerView;
    public WorkoutViewHolder(@NonNull View itemView) {
        super(itemView);
        this.exerciseTitleTv = itemView.findViewById(R.id.exercise_title_tv);
        this.addSetBtn = itemView.findViewById(R.id.add_set_btn);
        this.exerciseSetRecyclerView = itemView.findViewById(R.id.exercise_recyclerview);
    }
}
