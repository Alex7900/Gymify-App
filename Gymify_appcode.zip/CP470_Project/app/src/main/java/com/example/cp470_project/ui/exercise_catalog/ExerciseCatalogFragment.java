package com.example.cp470_project.ui.exercise_catalog;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.cp470_project.R;
import com.example.cp470_project.databinding.FragmentExerciseCatalogBinding;
import com.example.cp470_project.ui.exercise.Exercise;

import java.util.ArrayList;

public class ExerciseCatalogFragment extends Fragment {
    private FragmentExerciseCatalogBinding binding;
    private ExerciseAdapter adapter;
    private ArrayList<Exercise> exercises;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentExerciseCatalogBinding.inflate(inflater, container, false);

        // Chest Exercises
        String pushUpsTitle = getString(R.string.pushupsText);
        String pushUpsDesc = getString(R.string.pushupsDesc);
        String benchPressTitle = getString(R.string.benchpressText);
        String benchPressDesc = getString(R.string.benchpressDesc);
        String dumbbellFlyesTitle = getString(R.string.dumbbellFlyesText);
        String dumbbellFlyesDesc = getString(R.string.dumbbellFlyesDesc);

        // Arm Exercises
        String bicepCurlsTitle = getString(R.string.bicepCurlsText);
        String bicepCurlsDesc = getString(R.string.bicepCurlsDesc);
        String tricepDipsTitle = getString(R.string.tricepDipsText);
        String tricepDipsDesc = getString(R.string.tricepDipsDesc);
        String skullCrushersTitle = getString(R.string.skullCrushersText);
        String skullCrushersDesc = getString(R.string.skullCrushersDesc);

        // Back Exercises
        String deadliftsTitle = getString(R.string.deadliftsText);
        String deadliftsDesc = getString(R.string.deadliftsDesc);
        String pullUpsTitle = getString(R.string.pullUpsText);
        String pullUpsDesc = getString(R.string.pullUpsDesc);
        String bentOverRowsTitle = getString(R.string.bentOverRowsText);
        String bentOverRowsDesc = getString(R.string.bentOverRowsDesc);

        // Leg Exercises
        String legPressTitle = getString(R.string.legPressText);
        String legPressDesc = getString(R.string.legPressDesc);
        String calfRaisesTitle = getString(R.string.calfRaisesText);
        String calfRaisesDesc = getString(R.string.calfRaisesDesc);
        String legCurlsTitle = getString(R.string.legCurlsText);
        String legCurlsDesc = getString(R.string.legCurlsDesc);




        exercises = new ArrayList<>();
        // Chest exercises
        exercises.add(new Exercise(pushUpsTitle, pushUpsDesc, "pushups"));
        exercises.add(new Exercise(benchPressTitle, benchPressDesc, "benchpress"));
        exercises.add(new Exercise(dumbbellFlyesTitle, dumbbellFlyesDesc, "dumbbellfly"));

        // Arms exercises
        exercises.add(new Exercise(bicepCurlsTitle, bicepCurlsDesc, "bicepcurl"));
        exercises.add(new Exercise(tricepDipsTitle, tricepDipsDesc, "tricepdip"));
        exercises.add(new Exercise(skullCrushersTitle, skullCrushersDesc, "skullccrusher"));

        // Back exercises
        exercises.add(new Exercise(deadliftsTitle, deadliftsDesc, "deadlift"));
        exercises.add(new Exercise(pullUpsTitle, pullUpsDesc, "pullups"));
        exercises.add(new Exercise(bentOverRowsTitle, bentOverRowsDesc, "bentoverrow"));

        // Leg exercises
        exercises.add(new Exercise(legPressTitle, legPressDesc, "legpress"));
        exercises.add(new Exercise(calfRaisesTitle, calfRaisesDesc, "calfraise"));
        exercises.add(new Exercise(legCurlsTitle, legCurlsDesc, "legcurl"));

        // add more exercises ...

        // RecyclerView
        adapter = new ExerciseAdapter(container.getContext(),exercises);
        binding.exercisesRecyclerView.setLayoutManager(new LinearLayoutManager(container.getContext()));
        binding.exercisesRecyclerView.setAdapter(adapter);

        SearchView searchView = binding.exerciseSearchView;
        searchView.setQueryHint("Search Exercises");
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
        return binding.getRoot();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}