package com.example.cp470_project.ui.statistics;

import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_project.R;

public class StatisticsViewHolder extends RecyclerView.ViewHolder {
    private TextView name;
    private ProgressBar progress;
    public StatisticsViewHolder(@NonNull View itemView) {
        super(itemView);
        name = itemView.findViewById(R.id.statistic_name);
        progress = itemView.findViewById(R.id.statistic_progress);
    }
    public String getName(){
        return this.name.getText().toString();
    }

    public int getProgress(){
        return this.progress.getProgress();
    }

    public void setName(String name){
        this.name.setText(name);
    }

    public void setProgress(int progress){
        this.progress.setProgress(progress);
    }
}
