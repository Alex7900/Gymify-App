package com.example.cp470_project.ui.statistics;

import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_project.R;
import com.example.cp470_project.ui.statistics.CalendarAdapter;

public class CalendarViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
    private final TextView dayOfMonth;
    private final TextView notes;
    private final CalendarAdapter.OnItemListener listener;
    public CalendarViewHolder(@NonNull View itemView, CalendarAdapter.OnItemListener listener) {
        super(itemView);
        this.dayOfMonth = itemView.findViewById(R.id.dayText);
        this.notes = itemView.findViewById(R.id.notes);
        this.listener = listener;

        itemView.setOnClickListener(this);
    }

    public String getDayOfMonth(){
        return dayOfMonth.getText().toString();
    }

    public boolean setDayOfMonth(String day){
        this.dayOfMonth.setText(day);
        return true;
    }
    public String getNotes(){
        return notes.getText().toString();
    }

    public boolean setNotes(String notes){
        this.notes.setText(notes);
        this.notes.setVisibility(View.INVISIBLE);
        if (!notes.equals("")){
            dayOfMonth.setTextColor(Color.parseColor("#3BB143"));
        }
        return true;
    }

    @Override
    public void onClick(View v) {
        listener.onItemClick(getAdapterPosition(),notes.getText().toString());
    }
}
