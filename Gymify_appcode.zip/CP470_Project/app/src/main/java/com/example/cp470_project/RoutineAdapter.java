package com.example.cp470_project;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.cp470_project.ui.data.DatabaseHelper;
import com.example.cp470_project.ui.workout_logs.WorkoutLog;

import org.json.JSONArray;
import org.json.JSONException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RoutineAdapter extends ArrayAdapter<Routine> {
    DatabaseHelper databaseHelper = new DatabaseHelper(getContext());
    private SQLiteDatabase db = databaseHelper.getWritableDatabase();

    private String[] workoutRoutineName;
    private Context context;
    private List<Routine> routines;

    public RoutineAdapter(Context context, List<Routine> routines) {
        super(context, 0, routines);
        this.context = context;
        this.routines = routines;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Routine routine = routines.get(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.workout_routine, parent, false);
        }
        //routine = routines.get(workoutRoutineName[i]);

        TextView nameTextView = convertView.findViewById(R.id.workout_Name);
        TextView descriptionTextView = convertView.findViewById(R.id.workout_Desc);
        TextView exercisesTextView = convertView.findViewById(R.id.workout_Exercises);

        if(routine != null) {
            nameTextView.setText(routine.getName());
            descriptionTextView.setText(routine.getDescription());
            exercisesTextView.setText(routine.getExercises().toString());
            Button deleteButton = convertView.findViewById(R.id.routineDeleteButton);
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Handle delete button click
                    deleteRoutine(routine);
                }
            });

        }

        return convertView;
    }
    public void addNewRoutine(Routine newRoutine){
        routines.add(newRoutine);
        notifyDataSetChanged();
    }

    public void deleteRoutine(Routine routine){
        List<WorkoutLog> workoutLogs = getSavedWorkoutLogs();
        Boolean used = false;
        for(int i = 0; i < workoutLogs.size(); i++){
            WorkoutLog workout = workoutLogs.get(i);
            if(workout.getRoutineTitle().equals(routine.getName())){
                used = true;
            }
        }
        if(used){
            Toast.makeText(getContext(), "Routine in use, cannot be deleted.", Toast.LENGTH_SHORT).show();
        }
        else {
            routines.remove(routine);
            databaseHelper.deleteRoutineById(routine.getId());
            Toast.makeText(getContext(), "Routine deleted.", Toast.LENGTH_SHORT).show();
            notifyDataSetChanged();
        }
    }
    private List<WorkoutLog> getSavedWorkoutLogs() {
        String sqlQuery = "SELECT * FROM " + DatabaseHelper.TABLE_NAME_WORKOUT_LOG;
        Cursor cursor = db.rawQuery(sqlQuery, null);

        List<WorkoutLog> savedWorkoutLogs = new ArrayList<>();

        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            int cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_LOG_ID);
            int workoutLogID = cursor.getInt(cursorIndex);
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_LOG_TITLE);
            String title = cursor.getString(cursorIndex);
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_LOG_DATE_CREATED);
            LocalDate date = LocalDate.parse(cursor.getString(cursorIndex));
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_LOG_TIME_STARTED);
            LocalTime timeStarted = LocalTime.parse(cursor.getString(cursorIndex));
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_LOG_TIME_ENDED);
            LocalTime timeEnded = LocalTime.parse(cursor.getString(cursorIndex));
            cursorIndex = cursor.getColumnIndex(DatabaseHelper.KEY_WORKOUT_LOG_ROUTINE_NAME);
            String routineTitle = cursor.getString(cursorIndex);
            WorkoutLog workoutLog = new WorkoutLog(title, date, timeStarted, timeEnded, routineTitle);
            workoutLog.setWorkoutID(workoutLogID);
            savedWorkoutLogs.add(workoutLog);
            cursor.moveToNext();
        }
        cursor.close();
        savedWorkoutLogs.sort(new RoutineAdapter.WorkoutLogComparator() {
            @Override
            public int compare(WorkoutLog a, WorkoutLog b) {
                return super.compare(a, b);
            }
        });
        return savedWorkoutLogs;
    }
    private static class WorkoutLogComparator implements java.util.Comparator<WorkoutLog> {
        @Override
        public int compare(WorkoutLog a, WorkoutLog b) {
            return -a.getDateCreated().compareTo(b.getDateCreated());
        }
    }
}
