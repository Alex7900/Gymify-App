package com.example.cp470_project.ui.exercise_catalog;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cp470_project.R;

public class ExerciseViewHolder extends RecyclerView.ViewHolder {
    TextView exerciseName;
    TextView exerciseDescription;
    ImageView exerciseImage;

    public ExerciseViewHolder(@NonNull View itemView) {
        super(itemView);
        exerciseName = itemView.findViewById(R.id.exerciseName);
        exerciseDescription = itemView.findViewById(R.id.exerciseDescription);
        exerciseImage = itemView.findViewById(R.id.exerciseImage);
    }

}
